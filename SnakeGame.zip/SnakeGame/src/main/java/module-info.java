module com.game.snakegame {
    requires java.desktop;

    exports com.game.snakegame;
}